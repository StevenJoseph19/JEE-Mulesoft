package com.mycompany.client;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.mycompany.domain.Employee;

public class RestClientUtil {
	public void addEmployeeDemo1() throws URISyntaxException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		URI uri = new URI("http://localhost:8080/employee");
		Employee objEmp = new Employee();
		objEmp.setName("Krishna");
		objEmp.setCity("Noida");

		HttpEntity<Employee> httpEntity = new HttpEntity<>(objEmp, headers);
		System.out.println("In posts..");
		RestTemplate restTemplate = new RestTemplate();
		
		Employee employee = restTemplate.postForObject(uri, httpEntity, Employee.class);

		System.out.println("Id: " + employee.getEmpId());		
	}
	
	public void addEmployeeDemo2() throws URISyntaxException {
		URI uri = new URI("http://localhost:8080/employee");
		
		Employee objEmp = new Employee();
		objEmp.setName("Krishna");
		objEmp.setCity("Noida");

		RestTemplate restTemplate = new RestTemplate();
		Employee employee = restTemplate.postForObject(uri, objEmp, Employee.class);

		System.out.println("Id: " + employee.getEmpId());		
	}
	
	public void addEmployeeDemo3() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		String url = "http://localhost:8080/employee/{profile}/{tech}";

		Map<String, String> map = new HashMap<>();
		map.put("profile", "Developer");
		map.put("tech", "Java");

		Employee objEmp = new Employee();
		objEmp.setName("Krishna");
		objEmp.setCity("Noida");

		HttpEntity<Employee> httpEntity = new HttpEntity<>(objEmp, headers);

		RestTemplate restTemplate = new RestTemplate();
		Employee employee = restTemplate.postForObject(url, httpEntity, Employee.class, map);
        
		System.out.println("Id: " + employee.getEmpId());
	}
	
	public void addEmployeeDemo4() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		String url = "http://localhost:8080/employee/{profile}/{tech}";
		Employee objEmp = new Employee();
		objEmp.setName("Krishna");
		objEmp.setCity("Noida");
		
		HttpEntity<Employee> httpEntity = new HttpEntity<>(objEmp, headers);

		String profile = "Developer";
		String technology = "Java";
		RestTemplate restTemplate = new RestTemplate();
		Employee employee = restTemplate.postForObject(url, httpEntity, Employee.class, profile, technology);

		System.out.println("Id: " + employee.getEmpId());
	}

	public static void main(String args[]) throws URISyntaxException {
		RestClientUtil util = new RestClientUtil();
		util.addEmployeeDemo1();
		util.addEmployeeDemo2();
		util.addEmployeeDemo3();
		util.addEmployeeDemo4();
	}
}