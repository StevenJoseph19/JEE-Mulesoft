package com.mycompany.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.mycompany.domain.Employee;
import com.mycompany.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeService empService;

	@PostMapping(value = "employee")
	public ResponseEntity<Employee> addEmployee1(@RequestBody Employee employee, UriComponentsBuilder builder) {
		System.out.println("In controller..");
		empService.addEmployee(employee);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(builder.path("/employee/{id}").buildAndExpand(employee.getEmpId()).toUri());
		return new ResponseEntity<Employee>(employee, headers, HttpStatus.CREATED);
	}

	@PostMapping(value = "employee/{profile}/{tech}")
	public ResponseEntity<Employee> addEmployee2(@RequestBody Employee employee,
			@PathVariable("profile") String profile, @PathVariable("tech") String technology,
			UriComponentsBuilder builder) {

		System.out.println("Profile: " + profile);
		System.out.println("Technology: " + technology);

		empService.addEmployee(employee);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(builder.path("/employee/{id}").buildAndExpand(employee.getEmpId()).toUri());
		return new ResponseEntity<Employee>(employee, headers, HttpStatus.CREATED);
	}
}