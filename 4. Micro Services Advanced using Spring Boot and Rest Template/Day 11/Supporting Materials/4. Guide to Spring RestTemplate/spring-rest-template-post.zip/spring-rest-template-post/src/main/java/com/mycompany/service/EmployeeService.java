package com.mycompany.service;

import org.springframework.stereotype.Service;

import com.mycompany.domain.Employee;
@Service
public class EmployeeService {
	public void addEmployee(Employee emp) {
		emp.setEmpId(111);
		System.out.println("Name: " + emp.getName());
		System.out.println("City: " + emp.getCity());
	}
}