package com.mycompany.exception;

public class QueryHelperException extends RuntimeException {
    public QueryHelperException(String message, Throwable cause) {
        super(message, cause);
    }
}
