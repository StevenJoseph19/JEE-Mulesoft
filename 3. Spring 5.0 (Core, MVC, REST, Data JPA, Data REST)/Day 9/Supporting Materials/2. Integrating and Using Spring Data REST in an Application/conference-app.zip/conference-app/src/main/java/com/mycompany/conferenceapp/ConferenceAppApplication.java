package com.mycompany.conferenceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConferenceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConferenceAppApplication.class, args);
	}

}
