package com.mycompany.conferenceapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mycompany.conferenceapp.models.TicketType;

import java.util.List;

public interface TicketTypeJpaRepository extends JpaRepository<TicketType, String> {
    List<TicketType> findByIncludesWorkshopTrue();
}